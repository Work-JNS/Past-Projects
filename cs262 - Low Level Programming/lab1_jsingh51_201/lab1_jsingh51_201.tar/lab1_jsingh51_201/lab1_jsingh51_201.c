/* 

Jared Singh, G01416039
CS 262, Lab Section 201

Lab1: C version of "Hello World!"

*/

#include <stdio.h>

int main(){
	char name[100] = "Jared";
	printf("Hello World! my name is %s\n",name);
	return 0;
}
