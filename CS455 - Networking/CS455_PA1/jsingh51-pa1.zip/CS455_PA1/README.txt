Compilation Instructions:
	N/A: just run P1.py with "python3 P1.py" when in same directory

Runtime:
	user will be prompted with:
		$> my-dns-client 
	the user will enter a domain name: example.com
	they will receive an output
	this will be repeated a total of three times unless ctl-c
