//***************************************************************
// TODO: This is mostly done for you. See the "YOUR CODE HERE" spots below.
//***************************************************************


import edu.uci.ics.jung.graph.Forest;
import edu.uci.ics.jung.graph.Tree;

import edu.uci.ics.jung.graph.util.EdgeType;

import java.util.*;

/**
 *  This algorithm performs the steps to create a Huffman encoding
 *  build from a set of characters.
 *  
 *  @author Katherine (Raven) Russell and YOUR_NAME_HERE
 */
class HuffmanAlg implements FourEightyThreeForestAlg<HuffmanTreeNode,TreeEdge> {
	//*********************************************************************
	//*******                                                       *******
	//*******   You should not need to edit anything in this part.  *******
	//*******   However, you may need to read everything here.      *******
	//*******                                                       *******
	//*********************************************************************
	
	/**
	 *  The forest of huffman trees.
	 */
	Forest<HuffmanTreeNode, TreeEdge> forest;
	
	/**
	 *  Whether or not the algorithm has been started.
	 */
	private boolean started = false;
	
	/**
	 *  The possible modes the algorithm can be in.
	 */
	private enum Mode { COUNTING, BUILDING, ENCODING, DONE };
	
	/**
	 *  The algorithm's current mode.
	 */
	private Mode mode = null;
	
	/**
	 *  Current character (if in counting mode);
	 */
	private Character currentChar;
	
	/**
	 *  {@inheritDoc}
	 */
	public EdgeType TreeEdgeType() {
		return EdgeType.UNDIRECTED;
	}
	
	/**
	 *  Sets the current character being examined.
	 *  
	 *  @param currentChar the new character
	 */
	public void setCurrentChar(Character currentChar) {
		this.currentChar = currentChar;
	}
	
	/**
	 *  {@inheritDoc}
	 */
	public boolean isStarted() {
		return started;
	}
	
	/**
	 *  {@inheritDoc}
	 */
	public void start() {
		this.started = true;
	}
	
	/**
	 *  {@inheritDoc}
	 */
	public void finish() {
		// Unused. Required by the interface.
	}
	
	/**
	 *  {@inheritDoc}
	 */
	public void cleanUpLastStep() {
		// Unused. Required by the interface.
	}
	
	/**
	 *  {@inheritDoc}
	 */
	public boolean setupNextStep() {
		//we're counting, but out of characters
		if(this.mode == Mode.COUNTING && currentChar == null) {
			//start building
			this.mode = Mode.BUILDING;
		}
		
		//we're down to one tree, so stop building
		if(this.mode == Mode.BUILDING && this.forest.getTrees().size() <= 1) {
			//start encoding
			this.mode = Mode.ENCODING;
		}
		//you only get one step to do the encoding
		else if(this.mode == Mode.ENCODING) {
			//finished!
			this.mode = Mode.DONE;
		}
		
		return (this.mode != Mode.DONE);
	}
	
	//*********************************************************************
	//*******                                                       *******
	//*******    You have a number of things to do in this part.    *******
	//*******                                                       *******
	//*********************************************************************
	
	//YOUR CODE HERE
	//Any instance variables you'd find useful could go here!
	
	
	/**
	 *  {@inheritDoc}
	 */
	@SuppressWarnings("unchecked")
	public void reset(Forest<HuffmanTreeNode, TreeEdge> forest) {
		this.forest = forest;
		this.started = false;
		this.mode = Mode.COUNTING;
		this.currentChar = null;
		
		//YOUR CODE HERE
		
		//You may (or may not) want to (re)initialize some variables
		//before each run of the algorithm. You can do that here.
		//This is also called before the first run, so it can be
		//used in the same way as a constructor (to initialize).
	}
	
	/**
	 *  {@inheritDoc}
	 */
	public void doNextStep() {
		//YOUR CODE HERE
		
		/*
			Outline of what you need to do + some useful information.
			
			************************
			Counting Mode
			************************
			-- see if the current character has been seen before
			-- if it hasn't, you'll need to make a new node and add it to the forest (as a root)
			-- if it has, you'll need to update its count
			
			-- if you do this correctly, you will see nodes display (and have their counts
			   updated) in the simulator (ONE new node or ONE count increase per step)
			   
			-- Note: if you are in counting mode, then this.currentChar will be a character
			   (not null), this is set by the GUI (or the main method)
			
			
			************************
			Building Mode
			************************
			-- you need to follow the algorithm we covered in class: greedily select two roots,
			   join them under a new parent, the parent becomes a new root in the forest, the
			   count on the parent is the sum of the child node counts
			   
			-- if you do this correctly, you will see the trees build in the simulator (ONE
			   merge per step) and the "play" button will automatically stop when you are down
			   to 1 tree in the forest
			
			
			************************
			Encoding Mode
			************************
			-- you should set all the encodings for all the nodes in the tree using each
			   node's setEncoding() method
			   
			-- you only get one "step" of the algorithm to do this (i.e. all nodes need
			   to be set within one "step" of the algorithm)
			   
			-- you will likely need to read TreeEdge and OrderedDelegateForest carefully
			   to determine how to do this
			   
			-- Note: inner nodes do not *need* encodings, but you can add them if you want,
			   leaves *need* encodings (since those are the characters)
			
			-- if you do this correctly, the compressed text will display on the right hand
			   side of the simulator when you are done
			   
			-- Note: this algorithm is not designed to work with a single letter text (since you
			   don't actually create a tree this way), so if you run with the text "a" or "aaa"
			   or anything like that, it will say that the encoding isn't set, this is expected
			
			************************
			Useful Things to Know
			************************
			-- Things like Maps and PriorityQueues exist in Java. See:
			   https://docs.oracle.com/javase/tutorial/collections/TOC.html
			-- All of java.util has been imported for you, so feel free to use it!
			 
			-- HuffmanTreeNodes are already comparable (as in they implement the Comparable
			   interface). Whenever something is Comparable, you should use this fact when 
			   coding to ensure correct behavior! The compareTo() method has a tie breaker 
			   for equal-count nodes, so there shouldn't be any abiguity in how your tree
			   is created.
			
			-- this.mode is an enum. If you haven't seen them before, they're cool:
			   https://docs.oracle.com/javase/tutorial/java/javaOO/enum.html
			-- Enums can be checked using == with the static name, like so:
			   (this.mode == Mode.COUNTING)
			
			-- In the JUNG library, Forest is an interface, documentation of the interface
			   can be found here:
			   https://jung.sourceforge.net/doc/api/edu/uci/ics/jung/graph/Forest.html
			   From that page you can find the interface for Tree and other useful
			   classes.
			   
			-- this.forest is an (initially empty) forest of HuffmanTreeNodes 
			-- this.forest is (re)initialized before each run of the algorithm in the
			   reset() method
			-- Do NOT reinitialize the forest in doNextStep()!
			
			-- The mode advances for you, see setupNextStep() in this class, and
			   step() in FourEightyThreeForestAlg
			-- Do NOT advance the mode in doNextStep()!
			
			-- JUNG is a graph library, and a tree is a type of directed graph, so most
			   of the methods *sound* like graph methods and you'll need to do a little
			   "mental translation" to understand what they mean.
			-- For example, to add a new root to the forest, you can use the forest's
			   addVertex() method. This will add a new node to the graph with no parent
			   or child (i.e. a root).
			-- Another example is attaching a node to a child: making someone a child
			   is just adding an edge between the nodes (from parent to child) using
			   the forest's addEdge() method.
			
			-- Usage note on addEdge() for trees: addEdge() accepts an edge, the parent
			   node, and the child node (in that order). For an edge, you can simply
			   make a new TreeEdge (see TreeEdge.java).
		*/
	}
	
	//YOUR CODE HERE
	//Any helper methods you'd find useful could go here!
	
}