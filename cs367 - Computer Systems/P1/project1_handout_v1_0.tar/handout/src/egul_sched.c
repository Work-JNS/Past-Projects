/* This is the only file you will be editing.
 * - egul_sched.c (Egul Scheduler Library Code)
 * - Copyright of Starter Code: Prof. Kevin Andrea, George Mason University. All Rights Reserved
 * - Copyright of Student Code: You!  
 * - Copyright of ASCII Art: Modified from Joan Stark (jgs)'s work:
 * -- https://www.asciiart.eu/animals/birds-land
 * - Restrictions on Student Code: Do not post your code on any public site (eg. Github).
 * -- Feel free to post your code on a PRIVATE Github and give interviewers access to it.
 * -- You are liable for the protection of your code from others.
 * - Date: Aug 2024
 */

/* CS367 Project 1, Fall Semester, 2024
 * Fill in your Name, GNumber, and Section Number in the following comment fields
 * Name:
 * GNumber:
 * Section Number: CS367-00_             (Replace the _ with your section number)
 */

/* egul CPU Scheduling Library
                                                              __..-'
                                                        _.--''
                                              _...__..-'
                                            .'
                                          .'
                                        .'
                                      .'
           .------._                 ;
     .-"""`-.<')    `-._           .'
    (.--. _   `._       `'---.__.-'
     `   `;'-.-'         '-    ._ 
       .--'``  '._      - '   .   
        `""'-.    `---'    ,
''--..__      `\ 
        ``''---'`\      .'
             jgs  `'. '
                    `'.

*/
 
/* Standard Library Includes */
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
/* Unix System Includes */
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <pthread.h>
#include <sched.h>
/* Local Includes */
#include "egul_sched.h"
#include "strawhat_scheduler.h"
#include "strawhat_support.h"
#include "strawhat_process.h"

/* Feel free to create any definitions or constants you like! */

/* Feel free to create any helper functions you like! */

/*** Egul Library API Functions to Complete ***/

/* Initializes the Egul_schedule_s Struct and all of the Egul_queue_s Structs
 * Follow the project documentation for this function.
 * Returns a pointer to the new Egul_schedule_s or NULL on any error.
 * - Hint: What does malloc return on an error?
 */
Egul_schedule_s *egul_initialize() {
  return NULL; /* Replace This Line with your Code */
}

/* Allocate and Initialize a new Egul_process_s with the given information.
 * - Malloc and copy the command string, don't just assign it!
 * Follow the project documentation for this function.
 * - You may assume all arguments within data are Legal and Correct for this Function Only
 * Returns a pointer to the Egul_process_s on success or a NULL on any error.
 */
Egul_process_s *egul_create(Egul_create_data_s *data) {
  return NULL; /* Replace This Line with your Code */
}

/* Inserts a process into the Ready Queue (singly linked list).
 * Follow the project documentation for this function.
 * - Do not create a new process to insert, insert the SAME process passed in.
 * Returns a 0 on success or a -1 on any error.
 */
int egul_insert(Egul_schedule_s *schedule, Egul_process_s *process) {
  return -2; /* Replace This Line with your Code */
}

/* Returns the number of items in a given Egul Queue (singly linked list).
 * Follow the project documentation for this function.
 * Returns the number of processes in the list or -1 on any errors.
 */
int egul_count(Egul_queue_s *queue) {
  return -2; /* Replace This Line with your Code */
}

/* Selects the best process to run from the Ready Queue (singly linked list).
 * Follow the project documentation for this function.
 * Returns a pointer to the process selected or NULL if none available or on any errors.
 * - Do not create a new process to return, return a pointer to the SAME process selected.
 * - Return NULL if the ready queue was empty OR there were any errors.
 */
Egul_process_s *egul_select(Egul_schedule_s *schedule) {
  return NULL; /* Replace This Line with your Code */
}

/* Move the process with matching pid from Ready to Suspended Queue.
 * Follow the specification for this function.
 * Returns a 0 on success or a -1 on any error (such as process not found).
 */
int egul_suspend(Egul_schedule_s *schedule, pid_t pid) {
  return -2; /* Replace This Line with your Code */
}

/* Move the process with matching pid from Suspended to Ready Queue.
 * Follow the specification for this function.
 * Returns a 0 on success or a -1 on any error (such as process not found).
 */
int egul_resume(Egul_schedule_s *schedule, pid_t pid) {
  return -2; /* Replace This Line with your Code */
}

/* This is called when a process exits normally that was just Running.
 * Put the given node into the Terminated Queue and set the Exit Code 
 * - Do not create a new process to insert, insert the SAME process passed in.
 * Follow the project documentation for this function.
 * Returns a 0 on success or a -1 on any error.
 */
int egul_exited(Egul_schedule_s *schedule, Egul_process_s *process, int exit_code) {
  return -2; /* Replace This Line with your Code */
}

/* This is called when the OS terminates a process early. 
 * - This will either be in your Ready or Suspended Queue.
 * - The difference with egul_exited is that this process is in one of your Queues already.
 * Remove the process with matching pid from the Ready or Suspended Queue and add the Exit Code to it.
 * - You have to check both since it could be in either queue.
 * Follow the project documentation for this function.
 * Returns a 0 on success or a -1 on any error.
 */
int egul_killed(Egul_schedule_s *schedule, pid_t pid, int exit_code) {
  return -2; /* Replace This Line with your Code */
}

/* Gets the exit code from a terminated process.
 * (All Linux exit codes are between 0 and 255)
 * Follow the project documentation for this function.
 * Returns the exit code if the process is terminated.
 * If the process is not terminated, return -1.
 */
int egul_get_ec(Egul_process_s *process) {
  return -2; /* Replace This Line with your Code */
}

/* Frees all allocated memory in the Egul_schedule_s, all of the Queues, and all of their Nodes.
 * Follow the project documentation for this function.
 * Returns void.
 */
void egul_deallocate(Egul_schedule_s *schedule) {
  return; // Replace With Your Code
}