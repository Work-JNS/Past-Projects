Src files:
    lab1.go
    go.mod
Compile with:
    go build lab1.go
Run With:
    go run lab1.go
    ./lab1 * if Compiled
How to enter Information:
    the program will inform you as you go
    * for probability just enter in form of 0.xy
        where x & y are constants
    * otherwise just enter single integer
    * after entering anything press return key